<?php


namespace Twilio\Exceptions;


class HttpException extends TwilioException {

}