﻿<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host="localhost";
 $dbname="ziqqi_newzqdb";
 $username="ziqqi_zuser";
 $password="09hPM+AeI_MT";

 $zqdb1 = mysql_connect($host,$username,$password);
 mysql_select_db($dbname,$zqdb1);

?>
<?php
  $customers_arr = array();
  $customers_arr['records'] = array();

  $mobile = $_GET['phone'] ;
  $mobiles = '' ;

  //$customer_sql = "SELECT id, CONCAT(first_name,' ', last_name) as name , email , mobile FROM `customers` WHERE mobile !='' " ;
   $customer_sql = "SELECT * FROM `orders` WHERE bmobile = '$mobile' OR pickup_mobile = '$mobile' OR  pay_mobile  = '$mobile' ORDER BY id DESC LIMIT 1 " ;
  $customers_query = mysql_query($customer_sql);
  $num_customers = mysql_num_rows($customers_query);
  if($num_customers > 0)
  {

    while ($customers_rows = mysql_fetch_assoc($customers_query)) 
    {
       extract($customers_rows);

       if($pickup_mobile==$mobile)
       {
          $name =  $bfname.' '.$blname ;  
          $mobiles = $pickup_mobile;
       }
       elseif($bmobile==$mobile)
       {
         $name =  (empty($bfname)) ? $pickup_name : $bfname.' '.$blname ;
         $mobiles = $bmobile;
       }
       elseif($pay_mobile==$mobile)
       {
          $name = (empty($pickup_name)) ?  $bfname.' '.$blname : $pickup_name ;
          $mobiles = $pay_mobile;
       }
       else 
       {
         $error = 'The record doesnt exist.';
       }

        $customers_row=array( 'data' => array(
            "name" => $name,
            "email" => $bemail,
            "mobile" => $mobiles
          )
        );

     // $customers_row = $customers_rows ;
      //  array_push($customers_arr["records"], $customers_row);

    }

    }
    else
    {
       $customers_row=array( 'data' => array(
            "error" => 'The record doesnt exist.'
          )
        );
    }


     http_response_code(200);
    // show products data in json format
    echo json_encode($customers_row);

  

?>
