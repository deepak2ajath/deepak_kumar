﻿<?php
include('connection.php');
  $ $customers_arr = array();
  $customers_arr['records'] = array();

   $sql = "SELECT * FROM `orders` WHERE status = 'Out for Delivery' order by id desc limit 10";
  $qr = mysql_query($sql); 

  while($row = mysql_fetch_assoc($qr))
  {
     extract($row);


      $customers_row=array(
            "awb" => $id,
            "details"=>$pickup_name.'-'.$pickup_address_details,
            "address"=> array(
            "address"=> $pickup_address_details,
            "city"=>$pickup_city,
            "area"=> $pickup_location,
            "country"=> $pickup_country
           
          ),
           "customer"=> array(
            "name"=> $pickup_name,
            "phone"=> $pickup_mobile
          ),
          "pickupTask"=> true,
          "totalPrice"=> $grand_total,
          "paymentTypeId"=>  ($payment_gateway=='paypal') ? 2 : 1 
            
        );

     $data_string = json_encode($customers_row);

     $ch = curl_init('https://be.wimo.ae:3001/api/v1/tasks');                
     curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");               
     curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                 
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                     
     curl_setopt($ch, CURLOPT_HTTPHEADER, array(                             
        'Content-Type: application/json',
        'Authorization: e5dd671ac98575faf1edef6113d19e49',                                           
        'Content-Length: ' . strlen($data_string))                               
    );                                                                                                                   
                                                                                                                         
$result = curl_exec($ch);

       //array_push($customers_arr["records"], $customers_row);

  }

/* echo "<pre>"; print_r($customers_arr) ; echo "</pre>";

 foreach ($customers_arr as $arr) 
 {
   # code...
 }*/

/*$data = array(
  "awb"=>"1233111",
  "details"=>"The Test 2",
  "address"=> array(
    "address"=>"Street 5 - Dubai - United Arab Emirates",
    "city"=>"Dubai",
    "area"=> "Discovery Gardens",
    "country"=> "SOMALILAND",
    "streetNumber"=>"4",
    "streetName"=> "Street 4",
    "lat"=> 25.0445575,
    "lng"=> 55.1418511
  ),
   "customer"=> array(
    "name"=> "Customer 02",
    "phone"=> "+971501234567"
  ),
  "pickupTask"=> true,
  "totalPrice"=> 100,
  "paymentTypeId"=> 2 
);

echo $data_string = json_encode($data);*/                                                                                                                     
/*$ch = curl_init('https://be.wimo.ae:3001/api/v1/tasks');                
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");               
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                     
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                             
    'Content-Type: application/json',
    'Authorization: e5dd671ac98575faf1edef6113d19e49',                                           
    'Content-Length: ' . strlen($data_string))                               
);                                                                                                                   
                                                                                                                     
$result = curl_exec($ch);*/