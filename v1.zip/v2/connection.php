﻿<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

 $host="localhost";
 $dbname="ziqqi_newzqdb";
 $username="ziqqi_zuser";
 $password="09hPM+AeI_MT";

 $zqdb1 = mysql_connect($host,$username,$password);
 mysql_select_db($dbname,$zqdb1);

?>

