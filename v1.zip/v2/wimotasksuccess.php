﻿<?php
include('connection.php');
 
   $sql = "SELECT * FROM `orders` WHERE status = 'Out for Delivery' order by id desc limit 10";
   $qr = mysql_query($sql); 

  while($row = mysql_fetch_assoc($qr))
  {
     extract($row);

     $id = $row['id'] ;
     $bphonecode = $row['bphonecode'] ;
     $bmobile = $row['bmobile'] ;
   
     $ch = curl_init('https://be.wimo.ae:3001/api/v1/tasks/awb/'.$id);                
     curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");               
                     
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                     
     curl_setopt($ch, CURLOPT_HTTPHEADER, array(                             
        'Content-Type: application/json',
        'Authorization: e5dd671ac98575faf1edef6113d19e49'                                           
        )                               
     );                                                                                                                   
                                                                                                                         
    $result = curl_exec($ch);
    $resData = json_decode($result, true);
    $resTask = $resData['task']['status']['name'] ; 
    $resId  = $resData['task']['awb'];

   if($resTask =='Succeeded')
    {
     $sql = "UPDATE `orders` SET status ='Delivery Completed' , payment_status ='paid' where id = $resId " ; 
      $sql1 = "UPDATE `order_history` SET status ='Delivery Completed',status ='Delivery Completed' where orders_id = $resId " ; 
      
      mysql_query($sql) ;
      mysql_query($sql1) ;

      $adminnote="We look forward to your next order soon!";
      $status='Your Order Delivery Completed,  Order '.$id.'';

      $statusbar = 'statusbar_5' ; 
    
      $msg="Thank you! Your order has been successfully delivered. We look forward to serving you again soon."; 
      $mobilenumber = $bphonecode.$bmobile;
      sendSms($mobilenumber,$msg);

      $ordid = $id ; 

      include('../template/en/orders.php'); 

      $headers  = "MIME-Version: 1.0;\r\n"; 
      $headers .= "Content-type: text/html; charset=iso-8859-1;\r\n";
      $headers .="From: ".$site_email;
      $subject = "Ziqqi - Order Information";
      $m=0;
      //$m=mail($to,$subject,$body,$headers);
      aws_ses_mail($to,$site_email,$subject,$body); 
            
            // Admin Mail
      $headers1  = "MIME-Version: 1.0;\r\n"; 
      $headers1 .= "Content-type: text/html; charset=iso-8859-1;\r\n";
      $headers1 .="From: ".$site_email;
      $subject1 = "Ziqqi - Order Information";
      $m=0;
      $to1=$site_email;
      //$m=mail($to1,$subject1,$body,$headers1);
      aws_ses_mail($to1,$site_email,$subject1,$body);

    }

    



  

      

  }














 