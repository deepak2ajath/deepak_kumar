<?php


$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (!$update) {
  // receive wrong update, must not happen
  exit;
}

logf(json_encode($content));

/*curl https://api.smooch.io/v1/appusers/5790bff5237cbc5d00b10a17/conversation/messages \
     -X POST \
     -d '{"text":"Just put some vinegar on it", "role": "appMaker"}' \
     -H 'content-type: application/json' \
     -H 'authorization: Bearer your-jwt'
*/
$parameters["text"] = "Reply from the webhook!";
$parameters["role"] = "appMaker";

$handle = curl_init("https://api.smooch.io/v1/appusers/5c33226bb0645e0022b4ece1/conversation/messages");
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($handle, CURLOPT_TIMEOUT, 60);
curl_setopt($handle, CURLOPT_POSTFIELDS, json_encode($parameters));
curl_setopt($handle, CURLOPT_HTTPHEADER, 
    array("Content-Type: application/json; charset=utf-8","Authorization: Bearer ".MY_JWT)
);

$response = curl_exec($handle);
logf("response: ".$response);
$response = json_decode($response, true);

function logf($str){
    $logf = "smooch.txt";
    $dtnow = date("dmy H:i:s");
    $logfh = fopen($logf, 'a');
    $str = $dtnow." - ".$str."\n";
    fputs($logfh, $str);
    fclose($logfh);
}

?>